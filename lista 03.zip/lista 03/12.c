#include <stdio.h>

int main () {
	int i, n;
	n = 8;
	
	for (i = 1; i <= 10; i++) {
		printf("%d x %d = %d\n", i, n, i * n);
		
	}	

return 0;
}
