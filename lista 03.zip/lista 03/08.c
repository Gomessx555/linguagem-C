#include <stdio.h>

int main() {
    int n;

    for(n = 10; n >= 1; n--) {
        printf("%d\n", n);
    }

    return 0;
}

