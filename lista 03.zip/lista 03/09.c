#include <stdio.h>

int main() {
    int n;

    for(n = 101; n <= 110; n++) {
        printf("%d\n", n);
    }

    return 0;
}

